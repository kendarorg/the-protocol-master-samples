'use strict';

const WireGuard = require('../lib/WireGuard');

module.exports = new WireGuard();
